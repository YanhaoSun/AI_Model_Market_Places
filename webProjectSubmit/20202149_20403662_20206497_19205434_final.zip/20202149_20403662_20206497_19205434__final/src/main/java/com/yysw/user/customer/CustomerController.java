package com.yysw.user.customer;

import org.springframework.stereotype.Controller;

@Controller
public class CustomerController {

}
